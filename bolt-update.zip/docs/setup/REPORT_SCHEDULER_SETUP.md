# レポート自動生成スケジューラー - セットアップガイド

**作成日**: 2025年11月10日
**バージョン**: 1.0.0

---

## 📊 概要

レポート自動生成スケジューラーが**完全に実装**されています。

### 実装済みの機能

✅ **スケジュール管理UI**
- 週次・月次レポートのスケジュール作成
- スケジュールの有効化/無効化
- スケジュールの削除
- 実行履歴の表示

✅ **Edge Function**
- `scheduled-report-generator` - スケジュールに従ってレポートを自動生成

✅ **Supabase Cron Job**
- 毎時0分にスケジュールをチェック
- 実行すべきレポートを自動生成

✅ **データベース**
- `report_schedules` - スケジュール設定
- `report_generation_logs` - 実行ログ
- ヘルパー関数とトリガー

---

## 🏗️ システムアーキテクチャ

```
┌────────────────────────────────────────────────────────────┐
│ Supabase Cron Job (毎時0分実行)                             │
│ SELECT cron.schedule('generate-scheduled-reports', ...)    │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ Edge Function: scheduled-report-generator                  │
│ - report_schedulesから実行すべきスケジュールを取得          │
│ - 各スケジュールについてレポート生成                         │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ Edge Function: generate-ai-report                          │
│ - 指定期間のデータを集計                                     │
│ - OpenAI GPT-4でAI分析                                      │
│ - レポートを保存                                            │
└────────────────┬───────────────────────────────────────────┘
                 │
                 ▼
┌────────────────────────────────────────────────────────────┐
│ 通知・メール送信                                             │
│ - notification_emailsに設定されたメールアドレスに通知       │
│ - send-report-email Edge Functionで送信                    │
└────────────────────────────────────────────────────────────┘
```

---

## 🚀 セットアップ手順

### ステップ1: マイグレーションの実行

データベースマイグレーションを実行して、Cron Jobと必要な関数を作成します。

```bash
# Supabase CLIを使用
supabase db push

# または特定のマイグレーションのみ
supabase migration up
```

マイグレーションファイル:
- `20251110120000_setup_report_scheduler_cron.sql`

### ステップ2: Edge Functionのデプロイ

```bash
# スケジューラーをデプロイ
supabase functions deploy scheduled-report-generator

# レポート生成関数もデプロイ（未デプロイの場合）
supabase functions deploy generate-ai-report
```

### ステップ3: Supabase設定の確認

Supabase Dashboardで以下を確認:

1. **pg_cron拡張機能**
   - プロジェクト設定 → Database → Extensions
   - `pg_cron`が有効化されていることを確認

2. **Cron Jobの確認**
   ```sql
   SELECT * FROM cron.job WHERE jobname = 'generate-scheduled-reports';
   ```

   期待される結果:
   ```
   jobid | schedule  | command                      | nodename | nodeport | database | username | active | jobname
   ------+-----------+------------------------------+----------+----------+----------+----------+--------+-------------------------
   1     | 0 * * * * | SELECT net.http_post(...)    | ...      | ...      | ...      | ...      | true   | generate-scheduled-reports
   ```

### ステップ4: 環境変数の設定（オプション）

Cron Jobが環境変数を使用する場合、Supabase Secretsに設定:

```bash
# 必要に応じて
supabase secrets set OPENAI_API_KEY=sk-xxxxxxxxxxxxx
supabase secrets set RESEND_API_KEY=re-xxxxxxxxxxxxx
```

---

## 📝 使用方法

### 1. 管理画面からスケジュールを作成

1. 管理画面にログイン
2. 「管理設定」→「レポート自動生成スケジュール」を選択
3. 「スケジュール追加」をクリック

**設定項目**:
- **レポート種別**: 週次 or 月次
- **対象店舗**: 全店舗 or 特定店舗
- **通知先メールアドレス**: カンマ区切りで複数指定可能

### 2. スケジュールの例

#### 週次レポート
```
レポート種別: 週次
対象店舗: 全店舗
Cron式: 0 6 * * 1  (毎週月曜 6:00)
通知先: manager@example.com, owner@example.com
```

#### 月次レポート（特定店舗）
```
レポート種別: 月次
対象店舗: 新宿店
Cron式: 0 6 1 * *  (毎月1日 6:00)
通知先: shinjuku@example.com
```

### 3. スケジュールの有効化/無効化

- 一時的に停止したい場合は「無効化」ボタンをクリック
- 再開する場合は「有効化」ボタンをクリック

### 4. 実行履歴の確認

- 各スケジュールカードに「前回実行」と「次回実行」が表示されます
- 詳細なログは `report_generation_logs` テーブルを参照

---

## 🔧 Cron式の設定

### 基本フォーマット

```
分 時 日 月 曜日
│ │ │ │ │
│ │ │ │ └─ 曜日 (0-7, 0=日曜, 7=日曜)
│ │ │ └─── 月 (1-12)
│ │ └───── 日 (1-31)
│ └─────── 時 (0-23)
└───────── 分 (0-59)
```

### よく使うパターン

| 説明 | Cron式 | 備考 |
|------|--------|------|
| **毎週月曜 6:00** | `0 6 * * 1` | 週次レポートの推奨 |
| **毎月1日 6:00** | `0 6 1 * *` | 月次レポートの推奨 |
| **毎日 6:00** | `0 6 * * *` | 日次レポート |
| **毎週金曜 18:00** | `0 18 * * 5` | 週末前のレポート |
| **毎月最終日 23:00** | `0 23 L * *` | 月末レポート（※Lは未サポート） |

### カスタムCron式

UIから作成するスケジュールは自動的に適切なCron式が設定されますが、
データベースから直接カスタマイズも可能です:

```sql
UPDATE report_schedules
SET cron_expression = '0 18 * * 5',  -- 毎週金曜 18:00
    next_run_at = calculate_next_run_time('0 18 * * 5')
WHERE id = 'schedule-uuid';
```

---

## 🔍 トラブルシューティング

### レポートが生成されない

**1. Cron Jobが実行されているか確認**
```sql
SELECT jobname, last_run, last_run_status, run_details
FROM cron.job_run_details
WHERE jobname = 'generate-scheduled-reports'
ORDER BY start_time DESC
LIMIT 10;
```

**2. スケジュールが有効か確認**
```sql
SELECT id, report_type, is_enabled, next_run_at
FROM report_schedules
WHERE is_enabled = true;
```

**3. Edge Functionのログを確認**
```bash
supabase functions logs scheduled-report-generator --tail
```

### next_run_atが更新されない

**原因**: Edge Functionでの更新処理が失敗

**対処法**:
```sql
-- 手動で次回実行時刻を再計算
UPDATE report_schedules
SET next_run_at = calculate_next_run_time(cron_expression)
WHERE id = 'schedule-uuid';
```

### メールが届かない

**原因**: `notification_emails`が未設定またはメール送信エラー

**対処法**:
1. スケジュールの通知先メールアドレスを確認
2. `send-report-email` Edge Functionのログを確認
3. Resend APIキーが設定されているか確認

---

## 📊 データベーススキーマ

### report_schedules テーブル

| カラム名 | 型 | 説明 |
|---------|---|------|
| id | uuid | 主キー |
| organization_id | uuid | 組織ID（RLS） |
| report_type | text | 'weekly' or 'monthly' |
| store_id | uuid | 対象店舗（NULLは全店舗） |
| is_enabled | boolean | 有効/無効 |
| cron_expression | text | Cron式 |
| last_run_at | timestamptz | 前回実行日時 |
| next_run_at | timestamptz | 次回実行予定日時 |
| notification_emails | text[] | 通知先メールアドレス配列 |
| created_at | timestamptz | 作成日時 |
| updated_at | timestamptz | 更新日時 |

### report_generation_logs テーブル

| カラム名 | 型 | 説明 |
|---------|---|------|
| id | uuid | 主キー |
| organization_id | uuid | 組織ID（RLS） |
| schedule_id | uuid | スケジュールID（NULL可） |
| report_id | uuid | 生成されたレポートID |
| report_type | text | レポート種別 |
| store_id | uuid | 対象店舗 |
| status | text | 'success', 'failed', 'in_progress' |
| started_at | timestamptz | 開始日時 |
| completed_at | timestamptz | 完了日時 |
| error_message | text | エラーメッセージ |
| data_summary | jsonb | 実行サマリー |
| created_at | timestamptz | 作成日時 |

---

## 🎯 高度な機能

### 1. 複数店舗向けのバッチ処理

全店舗分のレポートを一度に生成:

```sql
INSERT INTO report_schedules (
  organization_id,
  report_type,
  store_id,
  cron_expression,
  is_enabled
)
SELECT
  'org-uuid',
  'weekly',
  id,
  '0 6 * * 1',
  true
FROM stores
WHERE organization_id = 'org-uuid';
```

### 2. カスタム実行ロジック

特定の条件でのみレポート生成:

```sql
-- 売上が一定額以上の店舗のみレポート生成
CREATE OR REPLACE FUNCTION should_generate_report(p_store_id uuid)
RETURNS boolean AS $$
DECLARE
  v_sales numeric;
BEGIN
  SELECT SUM(sales)
  INTO v_sales
  FROM daily_reports
  WHERE store_id = p_store_id
    AND date >= current_date - interval '7 days';

  RETURN v_sales > 1000000;  -- 100万円以上
END;
$$ LANGUAGE plpgsql;
```

### 3. 失敗時のリトライ

Edge Functionに実装:

```typescript
// scheduled-report-generator/index.ts
const MAX_RETRIES = 3;
let retryCount = 0;

while (retryCount < MAX_RETRIES) {
  try {
    await generateReport(...);
    break;
  } catch (error) {
    retryCount++;
    if (retryCount >= MAX_RETRIES) {
      // ログに記録して次のスケジュールへ
      await logFailure(schedule.id, error);
    }
    await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
  }
}
```

---

## 📈 モニタリングとメンテナンス

### 実行統計の確認

```sql
-- 過去30日間の実行統計
SELECT
  DATE(started_at) as execution_date,
  status,
  COUNT(*) as count
FROM report_generation_logs
WHERE started_at >= current_date - interval '30 days'
GROUP BY DATE(started_at), status
ORDER BY execution_date DESC;
```

### 失敗したレポートの確認

```sql
-- 失敗したレポート生成
SELECT
  rgl.id,
  rgl.started_at,
  rgl.error_message,
  rs.report_type,
  s.name as store_name
FROM report_generation_logs rgl
LEFT JOIN report_schedules rs ON rs.id = rgl.schedule_id
LEFT JOIN stores s ON s.id = rgl.store_id
WHERE rgl.status = 'failed'
ORDER BY rgl.started_at DESC
LIMIT 20;
```

### 古いログの削除

```sql
-- 90日以上前のログを削除
DELETE FROM report_generation_logs
WHERE started_at < current_date - interval '90 days';
```

---

## 🔐 セキュリティ考慮事項

### 1. RLS（Row Level Security）

すべてのテーブルでRLSが有効:
```sql
-- report_schedulesは組織ごとに分離
CREATE POLICY "Users can view own org schedules"
ON report_schedules
FOR SELECT
TO authenticated
USING (organization_id IN (
  SELECT organization_id FROM organization_members
  WHERE user_id = auth.uid()
));
```

### 2. 実行権限

Cron Jobは`SERVICE_ROLE_KEY`で実行されるため、
すべての組織のスケジュールにアクセス可能です。

Edge Function内でRLSポリシーが適切に適用されるよう注意してください。

### 3. レート制限

OpenAI APIのレート制限に注意:
- 組織あたりの同時リクエスト数を制限
- 失敗時は指数バックオフでリトライ

---

## 💡 ベストプラクティス

### 1. スケジュールの命名

わかりやすい命名規則を使用:
```
週次_全店舗_月曜朝
月次_新宿店_月初
```

### 2. 通知先の管理

- 複数の管理者を設定
- 重要なレポートは複数の通知先
- 店舗別レポートは店長のみ

### 3. 実行タイミング

- 負荷の少ない早朝に実行
- 同時実行を避けるため、時間をずらす
- データが確定した後に実行（例: 前日分のデータ）

### 4. エラーハンドリング

- 失敗しても次回のスケジュールに影響しない
- エラー通知を管理者に送信
- 自動リトライの実装

---

## 🎉 完了チェックリスト

### セットアップ

- [ ] マイグレーション実行
- [ ] pg_cron拡張機能の有効化確認
- [ ] Cron Jobの登録確認
- [ ] Edge Functionsのデプロイ
- [ ] テストスケジュールの作成

### テスト

- [ ] 手動でのレポート生成テスト
- [ ] スケジュール作成のテスト
- [ ] スケジュール有効化/無効化のテスト
- [ ] メール通知のテスト
- [ ] 実行ログの確認

### 本番運用

- [ ] 定期的なログ確認の設定
- [ ] 失敗時のアラート設定
- [ ] 古いログの自動削除設定
- [ ] バックアップの確認

---

## 📚 参考リンク

- [Supabase pg_cron](https://supabase.com/docs/guides/database/extensions/pg_cron)
- [Cron式の説明](https://crontab.guru/)
- [Edge Functions](https://supabase.com/docs/guides/functions)

---

**レポート自動生成スケジューラーが完全に機能します！** 🎊

定期的なレポート生成により、経営判断のスピードが大幅に向上します。
