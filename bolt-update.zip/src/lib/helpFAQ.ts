export interface FAQItem {
  id: string;
  keywords: string[];
  question: string;
  answer: string;
  category: 'basic' | 'reports' | 'dashboard' | 'settings' | 'data';
}

export const helpFAQs: FAQItem[] = [
  {
    id: 'daily-report-how',
    keywords: ['日報', '報告', '入力', '記入', 'レポート', 'どうやって'],
    question: '日報はどうやって入力しますか？',
    answer: 'サイドバーの「日報入力」をクリックして、売上や仕入れなどの情報を入力します。日付と店舗を選んで、数値を入力したら保存ボタンを押すだけで完了です。',
    category: 'reports',
  },
  {
    id: 'dashboard-view',
    keywords: ['ダッシュボード', '見方', '画面', '確認'],
    question: 'ダッシュボードの見方を教えてください',
    answer: 'ダッシュボードには今日・今週・今月の売上やKPIが表示されます。グラフやカードで視覚的に確認できるため、一目で状況を把握できます。上部の期間切り替えボタンで日次・週次・月次を切り替えることができます。',
    category: 'dashboard',
  },
  {
    id: 'store-add',
    keywords: ['店舗', '追加', '登録', '新規'],
    question: '店舗を追加するにはどうすればいいですか？',
    answer: '「管理画面」→「店舗管理」から新しい店舗を追加できます。店舗名、住所、連絡先などを入力して保存するだけです。複数店舗の管理にも対応しています。',
    category: 'settings',
  },
  {
    id: 'target-set',
    keywords: ['目標', '設定', 'ターゲット', '売上目標'],
    question: '売上目標を設定したいです',
    answer: '「目標設定」メニューから月次や日次の売上目標を設定できます。FLコスト率や営業利益率の目標も設定可能です。テンプレートも用意されているため、業態に合わせて選択できます。',
    category: 'settings',
  },
  {
    id: 'target-achievement',
    keywords: ['目標達成', '達成度', '進捗', 'パーセント', '目標', '確認', '見方'],
    question: '目標達成度はどこで確認できますか？',
    answer: 'ダッシュボードのKPIカードに目標達成度がパーセンテージで表示されます。売上目標に対する実績の比較、FLコスト率の達成状況など、各指標の達成度を一目で確認できます。達成度が高いと緑色、低いと赤色で表示されるため、すぐに状況を把握できます。日次・週次・月次の各ダッシュボードで確認可能です。',
    category: 'dashboard',
  },
  {
    id: 'monthly-target-input',
    keywords: ['月次目標', '入力', '設定', '方法', 'やり方', '月間目標'],
    question: '月次目標の入力方法を教えてください',
    answer: 'サイドバーの「目標設定」をクリックして、店舗と対象月を選択します。売上目標、FLコスト率目標、営業利益率目標などを入力できます。テンプレート機能を使えば、業態別（居酒屋、カフェ、レストランなど）の推奨値を自動で設定できるため便利です。目標を設定すると、ダッシュボードで達成度がリアルタイムで確認できるようになります。',
    category: 'settings',
  },
  {
    id: 'data-export',
    keywords: ['データ', 'エクスポート', '出力', 'ダウンロード', '書き出し'],
    question: 'データをエクスポートできますか？',
    answer: '「データ管理」メニューからExcel、CSV、PDFなど様々な形式でエクスポートできます。期間を指定して、必要なデータだけを出力することも可能です。',
    category: 'data',
  },
  {
    id: 'ai-chat',
    keywords: ['AI', 'チャット', '相談', '質問', '分析'],
    question: 'AIチャット機能の使い方は？',
    answer: 'AIチャットボタンをクリックすると、AIアシスタントに経営の相談ができます。売上分析や改善提案、データの解説など、様々な質問にお答えします。',
    category: 'basic',
  },
  {
    id: 'member-invite',
    keywords: ['メンバー', '招待', 'ユーザー', '追加', 'スタッフ'],
    question: 'スタッフを招待するには？',
    answer: '「組織設定」から新しいメンバーを招待できます。メールアドレスを入力して、役割（オーナー、マネージャー、スタッフ）を選択します。招待メールが自動で送信されます。',
    category: 'settings',
  },
  {
    id: 'kpi-meaning',
    keywords: ['KPI', '指標', 'FL', '意味', 'とは'],
    question: 'KPIって何ですか？',
    answer: 'KPI（重要業績評価指標）は、店舗の経営状態を測る重要な数値です。FLコスト率（食材費+人件費）、客単価、営業利益率などがあります。これらの指標を確認することで、店舗の経営状況を把握できます。',
    category: 'basic',
  },
  {
    id: 'report-edit',
    keywords: ['編集', '修正', '変更', '直す'],
    question: '入力した日報を修正できますか？',
    answer: '日報一覧から編集したい日報を選んで、修正ボタンを押すことで変更できます。入力ミスがあっても後から修正可能です。過去のデータも編集できます。',
    category: 'reports',
  },
  {
    id: 'monthly-expense',
    keywords: ['月次', '固定費', '経費', '人件費', '家賃', '光熱費', '消耗品'],
    question: '月次固定費入力の使い方を教えてください',
    answer: 'サイドバーの「月次固定費入力」から、店舗と対象月を選んで固定費を入力します。社員人件費、アルバイト人件費、家賃、光熱費、消耗品などを入力できます。「経費ベースライン設定」で標準経費を保存しておけば、毎月の入力時にデフォルト値として使用できるため便利です。正確な固定費を入力することで、より精度の高い利益分析が可能になります。',
    category: 'reports',
  },
  {
    id: 'notification',
    keywords: ['通知', 'お知らせ', 'アラート'],
    question: '通知機能はありますか？',
    answer: '目標未達成や異常値を検知した場合、システムから通知が届きます。通知の設定は「設定」メニューからカスタマイズできます。重要な情報を見逃さないようにお知らせします。',
    category: 'basic',
  },
  {
    id: 'mobile',
    keywords: ['スマホ', 'モバイル', '携帯', 'iPhone', 'Android'],
    question: 'スマホで使えますか？',
    answer: 'このシステムはスマートフォンにも対応しています。外出先でも快適に利用できます。レスポンシブデザインにより、画面サイズに合わせて最適化されます。',
    category: 'basic',
  },
  {
    id: 'demo-mode',
    keywords: ['デモ', 'お試し', '体験', 'サンプル'],
    question: 'デモモードってなんですか？',
    answer: 'デモモードは、登録なしでシステムを体験できる機能です。サンプルデータで全機能を試すことができるため、導入前の検討に最適です。気に入られた場合は本契約に移行できます。',
    category: 'basic',
  },
  {
    id: 'password-reset',
    keywords: ['パスワード', '忘れた', 'リセット', 'ログイン'],
    question: 'パスワードを忘れました',
    answer: 'ログイン画面の「パスワードを忘れた方」をクリックしてください。メールアドレスを入力すると、パスワードリセット用のリンクが送信されます。新しいパスワードを設定できます。',
    category: 'basic',
  },
  {
    id: 'csv-import',
    keywords: ['CSV', 'インポート', '取り込み', '一括'],
    question: 'CSVでデータを取り込めますか？',
    answer: '「データ管理」の「CSVインポート」から、既存のデータをまとめてアップロードできます。テンプレートもダウンロードできるため、指定のフォーマットに合わせて準備してください。',
    category: 'data',
  },
  {
    id: 'support',
    keywords: ['サポート', 'ヘルプ', '問い合わせ', '困った'],
    question: 'サポートに問い合わせたいです',
    answer: '画面右上のヘルプボタンから問い合わせフォームにアクセスできます。緊急の場合は、サポートメールに直接ご連絡ください。サポートチームが迅速に対応いたします。',
    category: 'basic',
  },
  {
    id: 'gamification-points',
    keywords: ['ポイント', '報酬', 'ゲーム', '日報', '入力', '得られる', 'もらえる'],
    question: '日報を入力するとポイントがもらえるのですか？',
    answer: '日報を入力すると、ゲーミフィケーション機能によりポイントが付与されます。毎日の日報入力を継続することで、より多くのポイントを獲得できます。連続入力ボーナスなども用意されており、日々の業務記録を楽しく続けられる仕組みになっています。',
    category: 'basic',
  },
  {
    id: 'points-usage',
    keywords: ['ポイント', '使い道', '使う', 'アバター', 'カスタマイズ', '交換', 'できること'],
    question: '獲得したポイントは何に使えますか？',
    answer: '獲得したポイントは、AIアシスタントのアバターカスタマイズに使用できます。様々な衣装、帽子、持ち物などのアイテムをポイントで購入し、自分だけのオリジナルアバターを作成できます。アバターカスタマイザーは、画面右下のアバターをクリックすることでアクセスできます。',
    category: 'basic',
  },
];

export const defaultGreeting = 'わんわん！ボクはこのシステムのAIアシスタントだワン！何か困ったことや分からないことがあったら、遠慮なく聞いてほしいワン。\n\n例えば、こんな質問に答えられるワン：\n・日報の入力方法\n・ダッシュボードの見方\n・店舗の追加方法\n・目標設定のやり方\n\n気軽に話しかけてワン！🐾';

export const noMatchResponse = 'うーん、その質問にはうまく答えられないワン...😅\n\nこんな質問なら得意だワン：\n・日報や目標の設定方法\n・ダッシュボードの使い方\n・データのエクスポート\n・店舗やメンバーの管理\n\nもう一度、違う言葉で聞いてみてほしいワン！';

export function findMatchingFAQ(userQuestion: string): FAQItem | null {
  const normalizedQuestion = userQuestion.toLowerCase();

  let bestMatch: FAQItem | null = null;
  let maxScore = 0;

  for (const faq of helpFAQs) {
    let score = 0;
    for (const keyword of faq.keywords) {
      if (normalizedQuestion.includes(keyword.toLowerCase())) {
        score++;
      }
    }

    if (score > maxScore) {
      maxScore = score;
      bestMatch = faq;
    }
  }

  return maxScore >= 1 ? bestMatch : null;
}

export function getQuickActions(): Array<{ label: string; question: string }> {
  return [
    { label: '📝 日報入力', question: '日報はどうやって入力しますか？' },
    { label: '📊 ダッシュボード', question: 'ダッシュボードの見方を教えてください' },
    { label: '🎯 目標設定', question: '売上目標を設定したいです' },
    { label: '💾 データ出力', question: 'データをエクスポートできますか？' },
  ];
}

export interface InputReaction {
  trigger: 'form-submit' | 'button-click' | 'data-change' | 'error' | 'success';
  messages: string[];
  emotion: 'normal' | 'happy' | 'sad' | 'thinking';
}

export const inputReactions: InputReaction[] = [
  {
    trigger: 'form-submit',
    messages: [
      'データを保存してるワン！もうちょっと待ってね🐾',
      '入力内容をチェックしてるワン！✨',
      '保存中だワン...ちょっとドキドキするワン💓',
    ],
    emotion: 'thinking',
  },
  {
    trigger: 'success',
    messages: [
      'やったワン！保存できたワン！🎉',
      '完璧だワン！グッジョブ！👍',
      '成功したワン！素晴らしいワン！✨',
      'バッチリだワン！次も頑張ろうワン！💪',
    ],
    emotion: 'happy',
  },
  {
    trigger: 'error',
    messages: [
      'あれれ...何か問題があったワン😢',
      'エラーが出ちゃったワン...もう一度試してみてワン',
      'うまくいかなかったワン...ごめんワン🙏',
    ],
    emotion: 'sad',
  },
  {
    trigger: 'button-click',
    messages: [
      'ポチッと押したワン！🔘',
      'よし、やるワン！💪',
      '了解だワン！',
    ],
    emotion: 'normal',
  },
  {
    trigger: 'data-change',
    messages: [
      'データが変わったワン！確認中だワン📊',
      'おっ、更新されたワン！チェックするワン✅',
      'データの変化を感知したワン！🔍',
    ],
    emotion: 'thinking',
  },
];

export function getRandomReaction(trigger: InputReaction['trigger']): { message: string; emotion: InputReaction['emotion'] } {
  const reactions = inputReactions.filter(r => r.trigger === trigger);
  if (reactions.length === 0) {
    return { message: '', emotion: 'normal' };
  }

  const reaction = reactions[0];
  const randomMessage = reaction.messages[Math.floor(Math.random() * reaction.messages.length)];

  return {
    message: randomMessage,
    emotion: reaction.emotion,
  };
}
