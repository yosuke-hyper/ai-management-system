type MessageType = 'success' | 'error' | 'loading' | 'info';

interface MessagePattern {
  pattern: RegExp;
  success?: string;
  error?: string;
  loading?: string;
  info?: string;
}

const messagePatterns: MessagePattern[] = [
  {
    pattern: /保存しました|保存完了|保存成功/i,
    success: 'バッチリ保存したワン！👍',
    loading: '保存中だワン...ちょっと待ってワン！'
  },
  {
    pattern: /削除しました|削除完了/i,
    success: '削除したワン！スッキリしたワン！🗑️',
    loading: '削除中だワン...',
    error: 'くぅ～ん💦 削除できなかったワン...'
  },
  {
    pattern: /更新しました|更新完了/i,
    success: '更新したワン！ピカピカだワン！✨',
    loading: '更新中だワン...',
    error: 'くぅ～ん💦 更新できなかったワン...'
  },
  {
    pattern: /作成しました|作成完了|登録しました|登録完了/i,
    success: '作成したワン！やったワン！🎉',
    loading: '作成中だワン...',
    error: 'くぅ～ん💦 作成できなかったワン...'
  },
  {
    pattern: /送信しました|送信完了/i,
    success: '送信したワン！届いたワン！📨',
    loading: '送信中だワン...',
    error: 'くぅ～ん💦 送信できなかったワン...'
  },
  {
    pattern: /コピーしました|コピー完了|コピー/i,
    success: 'コピーしたワン！📋',
    info: 'クリップボードにコピーしたワン！',
    error: 'くぅ～ん💦 コピーできなかったワン...'
  },
  {
    pattern: /前日のデータが見つからなかった/i,
    info: '前日のデータが見つからなかったワン...📝'
  },
  {
    pattern: /データが見つからなかった|データがない/i,
    info: 'データが見つからなかったワン...📝',
    error: 'くぅ～ん💦 データの取得に失敗したワン...'
  },
  {
    pattern: /アップロード|インポート/i,
    success: 'アップロードしたワン！バッチリだワン！📤',
    loading: 'アップロード中だワン...',
    error: 'くぅ～ん💦 アップロードできなかったワン...'
  },
  {
    pattern: /エクスポート|ダウンロード/i,
    success: 'ダウンロードしたワン！受け取ってワン！📥',
    loading: 'ダウンロード中だワン...',
    error: 'くぅ～ん💦 ダウンロードできなかったワン...'
  },
  {
    pattern: /認証|ログイン/i,
    success: 'ログインしたワン！おかえりワン！🐾',
    loading: 'ログイン中だワン...',
    error: 'くぅ～ん💦 ログインできなかったワン...'
  },
  {
    pattern: /ログアウト/i,
    success: 'ログアウトしたワン！またねワン！👋',
    loading: 'ログアウト中だワン...'
  },
  {
    pattern: /招待|invite/i,
    success: '招待メールを送ったワン！📬',
    loading: '招待メール送信中だワン...',
    error: 'くぅ～ん💦 招待メールを送れなかったワン...'
  },
  {
    pattern: /目標達成|達成/i,
    success: 'わぁ～い！目標達成だワン！🎯✨',
    info: 'おめでとうワン！すごいワン！'
  },
  {
    pattern: /エラー|失敗|error|failed/i,
    error: 'くぅ～ん💦 うまくいかなかったワン...',
    info: 'もう一度試してほしいワン！'
  },
  {
    pattern: /接続|connect/i,
    success: '接続したワン！準備OKだワン！🔌',
    loading: '接続中だワン...',
    error: 'くぅ～ん💦 接続できなかったワン...'
  },
  {
    pattern: /同期|sync/i,
    success: '同期したワン！最新だワン！🔄',
    loading: '同期中だワン...',
    error: 'くぅ～ん💦 同期できなかったワン...'
  },
  {
    pattern: /検証|verify/i,
    success: '検証OKだワン！バッチリだワン！✅',
    loading: '検証中だワン...',
    error: 'くぅ～ん💦 検証できなかったワン...'
  },
  {
    pattern: /処理完了|complete/i,
    success: '処理完了したワン！お疲れ様ワン！🎊',
    loading: '処理中だワン...'
  }
];

const defaultMessages = {
  success: 'できたワン！👍',
  error: 'くぅ～ん💦 うまくいかなかったワン...',
  loading: '処理中だワン...ちょっと待ってワン！',
  info: 'お知らせだワン！📢'
};

export function convertToAvatarMessage(message: string, type: MessageType): string {
  if (!message) {
    return defaultMessages[type];
  }

  for (const pattern of messagePatterns) {
    if (pattern.pattern.test(message)) {
      const avatarMessage = pattern[type];
      if (avatarMessage) {
        return avatarMessage;
      }
    }
  }

  return defaultMessages[type];
}

export function getEmotionForMessageType(type: MessageType): 'happy' | 'sad' | 'thinking' | 'normal' {
  switch (type) {
    case 'success':
      return 'happy';
    case 'error':
      return 'sad';
    case 'loading':
      return 'thinking';
    case 'info':
      return 'normal';
    default:
      return 'normal';
  }
}
